from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import numpy as np
from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from underline_retldc.app.settings import THEME_LIGHT, Theme_Normalize
from underline_retldc.core.dataset import Dataset
from underline_retldc.core.project_data import ChannelReference
from underline_retldc.core.regions import BurnCandidate, RegionSelection, TimeRegion
from underline_retldc.core.segmentation import Segmentation_RegionsAroundCandidate
from underline_retldc.gui.analysis_widgets import AnalysisPlotWidget
from underline_retldc.gui.schema_form import SchemaForm
from underline_retldc.gui.widgets import StandardComboBox
from underline_retldc.i18n.service import TranslationService


class ProcessPage(QWidget):
    detect_requested = Signal()
    apply_requested = Signal()
    plugins_requested = Signal()
    regions_changed = Signal()
    primary_thrust_changed = Signal(object)
    select_thrust_requested = Signal()

    def __init__(self, translations: TranslationService) -> None:
        super().__init__()
        self._translations = translations
        self._raw_dataset: Dataset | None = None
        self._calibrated_dataset: Dataset | None = None
        self._processed_dataset: Dataset | None = None
        self._input_channel_id: str | None = None
        self._thrust_references: dict[str, ChannelReference] = {}
        self._candidates: list[BurnCandidate] = []
        self._processors: tuple[Any, ...] = ()
        self._curve_items: list[Any] = []
        self._regions_syncing = False
        self._theme = THEME_LIGHT
        self._display_preferences: dict[str, str] = {}

        self.analysis_plot = AnalysisPlotWidget(
            translations,
            regions_movable=True,
        )
        # Compatibility aliases retained for extensions and existing tests.
        self.plot_widget = self.analysis_plot.plot_widget
        self.plot_legend = self.analysis_plot.legend
        self.pre_region = self.analysis_plot.pre_region
        self.burn_region = self.analysis_plot.active_region
        self.post_region = self.analysis_plot.post_region
        for region in (self.pre_region, self.burn_region, self.post_region):
            region.sigRegionChanged.connect(self._region_edits_refresh)
            region.sigRegionChangeFinished.connect(self.regions_changed)
        self.analysis_plot.select_channel_requested.connect(
            self.select_thrust_requested
        )

        controls = QWidget()
        controls.setMinimumWidth(310)
        controls.setMaximumWidth(380)
        controls_layout = QVBoxLayout(controls)
        self.input_group = QGroupBox()
        input_layout = QVBoxLayout(self.input_group)
        self.input_label = QLabel()
        self.input_combo = StandardComboBox()
        self.input_combo.currentIndexChanged.connect(self._input_selection_changed)
        self.select_input_button = QPushButton()
        self.select_input_button.clicked.connect(self.select_thrust_requested)
        self.input_hint = QLabel()
        self.input_hint.setWordWrap(True)
        input_layout.addWidget(self.input_label)
        input_layout.addWidget(self.input_combo)
        input_layout.addWidget(self.select_input_button)
        input_layout.addWidget(self.input_hint)
        controls_layout.addWidget(self.input_group)
        self.curves_group = QGroupBox()
        curves_layout = QVBoxLayout(self.curves_group)
        self.curve_checks: dict[str, QCheckBox] = {}
        for key in ("uncorrected", "corrected"):
            checkbox = QCheckBox()
            checkbox.setChecked(True)
            checkbox.toggled.connect(self._plot_refresh)
            self.curve_checks[key] = checkbox
            curves_layout.addWidget(checkbox)
        controls_layout.addWidget(self.curves_group)

        self.candidates_group = QGroupBox()
        candidates_layout = QVBoxLayout(self.candidates_group)
        self.detect_button = QPushButton()
        self.detect_button.clicked.connect(self.detect_requested)
        self.fit_button = QPushButton()
        self.fit_button.clicked.connect(self._regions_view_fit)
        self.candidate_combo = StandardComboBox()
        self.candidate_combo.currentIndexChanged.connect(self._candidate_selected)
        self.region_hint = QLabel()
        self.region_hint.setWordWrap(True)
        candidate_buttons = QHBoxLayout()
        candidate_buttons.addWidget(self.detect_button)
        candidate_buttons.addWidget(self.fit_button)
        candidates_layout.addLayout(candidate_buttons)
        candidates_layout.addWidget(self.candidate_combo)
        candidates_layout.addWidget(self.region_hint)
        controls_layout.addWidget(self.candidates_group)

        self.regions_group = QGroupBox()
        regions_layout = QFormLayout(self.regions_group)
        self.region_labels: dict[str, QLabel] = {}
        self.region_edits: dict[str, tuple[QDoubleSpinBox, QDoubleSpinBox]] = {}
        self.region_use_checks: dict[str, QCheckBox] = {}
        for region_name in ("pre", "burn", "post"):
            label = QLabel()
            start_edit = QDoubleSpinBox()
            end_edit = QDoubleSpinBox()
            for edit in (start_edit, end_edit):
                edit.setDecimals(8)
                edit.setRange(-1.0e12, 1.0e12)
                edit.setMinimumWidth(122)
                edit.setMaximumWidth(145)
                edit.setAlignment(Qt.AlignmentFlag.AlignRight)
                edit.setSuffix(" s")
                edit.setKeyboardTracking(False)
                edit.setStepType(QDoubleSpinBox.StepType.AdaptiveDecimalStepType)
                edit.valueChanged.connect(self._regions_update_from_edits)
            row = QHBoxLayout()
            if region_name != "burn":
                use_check = QCheckBox()
                use_check.setChecked(True)
                use_check.toggled.connect(self._region_availability_changed)
                self.region_use_checks[region_name] = use_check
                row.addWidget(use_check)
            row.addWidget(start_edit)
            row.addWidget(QLabel("→"))
            row.addWidget(end_edit)
            self.region_labels[region_name] = label
            self.region_edits[region_name] = (start_edit, end_edit)
            regions_layout.addRow(label, row)
        controls_layout.addWidget(self.regions_group)

        self.baseline_status_group = QGroupBox()
        baseline_status_layout = QFormLayout(self.baseline_status_group)
        self.baseline_status_labels = {"pre": QLabel(), "post": QLabel()}
        self.baseline_status_values = {"pre": QLabel("—"), "post": QLabel("—")}
        for name in ("pre", "post"):
            baseline_status_layout.addRow(
                self.baseline_status_labels[name], self.baseline_status_values[name]
            )
        controls_layout.addWidget(self.baseline_status_group)

        self.processing_group = QGroupBox()
        processing_layout = QFormLayout(self.processing_group)
        self.compensation_label = QLabel()
        self.processor_combo = StandardComboBox()
        self.processor_combo.currentIndexChanged.connect(self._processor_schema_update)
        self.plugins_button = QPushButton()
        self.plugins_button.clicked.connect(self.plugins_requested)
        processor_row = QHBoxLayout()
        processor_row.addWidget(self.processor_combo, 1)
        processor_row.addWidget(self.plugins_button)
        self.processor_form = SchemaForm(translations)
        self.apply_button = QPushButton()
        self.apply_button.setObjectName("primaryButton")
        self.apply_button.clicked.connect(self.apply_requested)
        processing_layout.addRow(self.compensation_label, processor_row)
        processing_layout.addRow(self.processor_form)
        processing_layout.addRow(self.apply_button)
        controls_layout.addWidget(self.processing_group)
        controls_layout.addStretch(1)

        self.controls_widget = controls
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(controls)
        self.retranslate()

    def retranslate(self) -> None:
        t = self._translations.translate
        self.curves_group.setTitle(t("process.curves"))
        self.input_group.setTitle(t("primary_channels.title"))
        self.input_label.setText(t("workspace.thrust_data"))
        self.select_input_button.setText(t("workspace.select_thrust"))
        for key, checkbox in self.curve_checks.items():
            checkbox.setText(t(f"process.{key}"))
        self.candidates_group.setTitle(t("process.candidates"))
        self.detect_button.setText(t("process.detect_candidates"))
        self.fit_button.setText(t("process.fit_regions"))
        self.processing_group.setTitle(t("page.process"))
        self.compensation_label.setText(t("process.enable_baseline"))
        self.plugins_button.setText(t("process.plugins"))
        self.apply_button.setText(t("process.apply"))
        self.region_hint.setText(t("process.region_hint"))
        self.regions_group.setTitle(t("process.manual_regions"))
        for region_name, label in self.region_labels.items():
            label.setText(t(f"process.{region_name}"))
        self.baseline_status_group.setTitle(t("process.baseline_status"))
        self.baseline_status_labels["pre"].setText(t("process.pre_baseline"))
        self.baseline_status_labels["post"].setText(t("process.post_baseline"))
        self.analysis_plot.set_axis(
            x_label=t("common.time"),
            y_label=t("common.value"),
        )
        self.analysis_plot.empty_button.setText(t("workspace.select_thrust"))
        selected_processor = self.processor_id()
        processor_values = (
            self.processor_form.values() if self.processor_form.field_names else {}
        )
        self._processors_populate(selected_processor)
        self.processor_form.set_values(processor_values)
        self.processor_form.retranslate()
        self._candidate_labels_update()
        self._plot_refresh()

    def set_datasets(
        self,
        raw_dataset: Dataset | None,
        calibrated_dataset: Dataset | None,
        processed_dataset: Dataset | None,
        *,
        input_channel_id: str | None = None,
    ) -> None:
        self._raw_dataset = raw_dataset
        self._calibrated_dataset = calibrated_dataset
        self._processed_dataset = processed_dataset
        self._input_channel_id = input_channel_id
        self.input_hint.setText(
            ""
            if input_channel_id is not None
            else self._translations.translate("workspace.no_primary_thrust")
        )
        self.apply_button.setEnabled(input_channel_id is not None)
        self.detect_button.setEnabled(input_channel_id is not None)
        self._plot_refresh()
        dataset = calibrated_dataset or raw_dataset
        if dataset is not None and dataset.sample_count >= 2:
            project_time = dataset.project_time
            finite_time = project_time[np.isfinite(project_time)]
            if finite_time.size >= 2 and not self.pre_region.isVisible():
                start = float(np.min(finite_time))
                end = float(np.max(finite_time))
                span = end - start
                self.set_regions(
                    {
                        "pre": [start, start + 0.2 * span],
                        "burn": [start + 0.3 * span, start + 0.7 * span],
                        "post": [start + 0.8 * span, end],
                    }
                )

    def set_thrust_choices(
        self,
        choices: tuple[tuple[str, object], ...],
        selected: object | None,
    ) -> None:
        self.input_combo.blockSignals(True)
        self.input_combo.clear()
        self._thrust_references.clear()
        self.input_combo.addItem(
            self._translations.translate("primary_channels.none"),
            None,
        )
        for label, reference in choices:
            if not isinstance(reference, ChannelReference):
                continue
            self._thrust_references[reference.stable_id] = reference
            self.input_combo.addItem(label, reference.stable_id)
        selected_id = selected.stable_id if isinstance(selected, ChannelReference) else None
        index = self.input_combo.findData(selected_id)
        self.input_combo.setCurrentIndex(max(0, index))
        self.input_combo.blockSignals(False)

    def _input_selection_changed(self, _index: int) -> None:
        stable_id = self.input_combo.currentData()
        self.primary_thrust_changed.emit(
            self._thrust_references.get(str(stable_id)) if stable_id else None
        )

    def set_candidates(self, candidates: list[BurnCandidate]) -> None:
        self._candidates = list(candidates)
        self._candidate_labels_update()
        if candidates:
            self.candidate_combo.setCurrentIndex(0)
            self._candidate_selected(0)

    def _candidate_labels_update(self) -> None:
        current = self.candidate_combo.currentIndex()
        self.candidate_combo.blockSignals(True)
        self.candidate_combo.clear()
        if not self._candidates:
            self.candidate_combo.addItem(
                self._translations.translate("process.not_detected"), None
            )
        for index, candidate in enumerate(self._candidates):
            prefix = (
                self._translations.translate("process.recommended") + " — "
                if index == 0
                else ""
            )
            self.candidate_combo.addItem(
                self._translations.translate(
                    "process.candidate_line",
                    prefix=prefix,
                    start=f"{candidate.start:.5g}",
                    end=f"{candidate.end:.5g}",
                    peak=f"{candidate.peak:.5g}",
                    score=f"{candidate.score:.4g}",
                ),
                index,
            )
        if self._candidates:
            self.candidate_combo.setCurrentIndex(min(max(current, 0), len(self._candidates) - 1))
        self.candidate_combo.blockSignals(False)

    def _candidate_selected(self, index: int) -> None:
        if index < 0 or index >= len(self._candidates):
            return
        dataset = self._calibrated_dataset or self._raw_dataset
        if dataset is None:
            return
        candidate = self._candidates[index]
        selection = Segmentation_RegionsAroundCandidate(dataset, candidate)
        self.set_regions(selection.to_dict())

    def set_regions(
        self,
        regions: Mapping[str, list[float] | tuple[float, float] | None],
    ) -> None:
        payload = {
            key: (
                list(map(float, regions[key]))
                if regions.get(key) is not None
                else None
            )
            for key in ("pre", "burn", "post")
        }
        selection = RegionSelection.from_dict(payload)
        self._regions_syncing = True
        if selection.pre is not None:
            self.pre_region.setRegion(selection.pre.to_list())
        self.burn_region.setRegion(selection.burn.to_list())
        if selection.post is not None:
            self.post_region.setRegion(selection.post.to_list())
        self.pre_region.setVisible(selection.pre is not None)
        self.burn_region.setVisible(True)
        self.post_region.setVisible(selection.post is not None)
        for name, available in (
            ("pre", selection.pre is not None),
            ("post", selection.post is not None),
        ):
            self.region_use_checks[name].blockSignals(True)
            self.region_use_checks[name].setChecked(available)
            self.region_use_checks[name].blockSignals(False)
            for edit in self.region_edits[name]:
                edit.setEnabled(available)
        self._regions_syncing = False
        self._region_edits_refresh()
        self.regions_changed.emit()

    def _region_availability_changed(self, _checked: bool) -> None:
        if self._regions_syncing:
            return
        for name, region in (("pre", self.pre_region), ("post", self.post_region)):
            available = self.region_use_checks[name].isChecked()
            region.setVisible(available)
            for edit in self.region_edits[name]:
                edit.setEnabled(available)
        self.regions_changed.emit()

    def _region_edits_refresh(self) -> None:
        if self._regions_syncing:
            return
        self._regions_syncing = True
        for region_name, region in (
            ("pre", self.pre_region),
            ("burn", self.burn_region),
            ("post", self.post_region),
        ):
            if region_name != "burn" and not self.region_use_checks[region_name].isChecked():
                continue
            start_edit, end_edit = self.region_edits[region_name]
            start, end = map(float, region.getRegion())
            start_edit.setValue(start)
            end_edit.setValue(end)
        self._regions_syncing = False

    def _regions_update_from_edits(self) -> None:
        if self._regions_syncing:
            return
        payload = {}
        for region_name, (start_edit, end_edit) in self.region_edits.items():
            payload[region_name] = (
                None
                if region_name != "burn"
                and not self.region_use_checks[region_name].isChecked()
                else [start_edit.value(), end_edit.value()]
            )
        try:
            selection = RegionSelection.from_dict(payload)
        except ValueError:
            self._region_edits_refresh()
            return
        self._regions_syncing = True
        if selection.pre is not None:
            self.pre_region.setRegion(selection.pre.to_list())
        self.burn_region.setRegion(selection.burn.to_list())
        if selection.post is not None:
            self.post_region.setRegion(selection.post.to_list())
        self.pre_region.setVisible(selection.pre is not None)
        self.burn_region.setVisible(True)
        self.post_region.setVisible(selection.post is not None)
        self._regions_syncing = False
        self.regions_changed.emit()

    def regions(self) -> dict[str, list[float] | None]:
        selection = RegionSelection(
            pre=(
                TimeRegion(*map(float, self.pre_region.getRegion()))
                if self.region_use_checks["pre"].isChecked()
                else None
            ),
            burn=TimeRegion(*map(float, self.burn_region.getRegion())),
            post=(
                TimeRegion(*map(float, self.post_region.getRegion()))
                if self.region_use_checks["post"].isChecked()
                else None
            ),
        )
        return selection.to_dict()

    def set_processors(
        self,
        processors: tuple[Any, ...],
        *,
        preferred_id: str | None,
    ) -> None:
        previous_id = self.processor_id()
        previous_values = (
            self.processor_form.values() if self.processor_form.field_names else {}
        )
        self._processors = tuple(processors)
        self._processors_populate(preferred_id)
        if preferred_id == previous_id:
            self.processor_form.set_values(previous_values)

    def _processors_populate(self, selected: str | None) -> None:
        self.processor_combo.blockSignals(True)
        self.processor_combo.clear()
        self.processor_combo.addItem(
            self._translations.translate("process.processor_none"), None
        )
        for processor in self._processors:
            descriptor = processor.descriptor
            self.processor_combo.addItem(
                self._translations.translate(
                    descriptor.translation_key or "", descriptor.name
                ),
                descriptor.plugin_id,
            )
        index = self.processor_combo.findData(selected)
        self.processor_combo.setCurrentIndex(max(0, index))
        self.processor_combo.blockSignals(False)
        self._processor_schema_update()

    def _processor_schema_update(self, _index: int | None = None) -> None:
        processor = self._selected_processor()
        if processor is None:
            self.processor_form.set_schema({"type": "object", "properties": {}})
            return
        self.processor_form.set_schema(processor.config_schema())

    def _selected_processor(self) -> Any | None:
        plugin_id = self.processor_id()
        return next(
            (
                processor
                for processor in self._processors
                if processor.descriptor.plugin_id == plugin_id
            ),
            None,
        )

    def processor_id(self) -> str | None:
        plugin_id = self.processor_combo.currentData()
        return str(plugin_id) if plugin_id else None

    @property
    def input_channel_id(self) -> str | None:
        return self._input_channel_id

    def processing_config(self) -> dict[str, Any]:
        processor = self._selected_processor()
        if processor is None:
            return {}
        schema = processor.config_schema()
        raw_properties = schema.get("properties", {})
        if not isinstance(raw_properties, Mapping):
            raise ValueError("Processor config schema properties must be an object")
        config = self.processor_form.values()
        injected = {
            "processor.selection": True,
            "thrust_analysis.input_channel": self._input_channel_id,
            "thrust_analysis.regions": self.regions(),
        }
        if self._input_channel_id is None:
            raise ValueError("The Project has no Primary Thrust Channel")
        for field_name, raw_property in raw_properties.items():
            if not isinstance(raw_property, Mapping):
                raise ValueError(f"Processor schema field {field_name!r} must be an object")
            source = raw_property.get("x-ui-source")
            if source is not None:
                try:
                    config[str(field_name)] = injected[str(source)]
                except KeyError as exc:
                    raise ValueError(
                        f"Unsupported Processor x-ui-source {source!r}"
                    ) from exc
            elif bool(raw_property.get("x-ui-hidden", False)) and "default" in raw_property:
                config[str(field_name)] = raw_property["default"]
        return config

    def set_processing_config(
        self, plugin_id: str | None, config: Mapping[str, Any]
    ) -> None:
        index = self.processor_combo.findData(plugin_id)
        if index < 0:
            raise ValueError(f"Processor {plugin_id!r} is not available")
        self.processor_combo.setCurrentIndex(index)
        self.processor_form.set_values(config)
        if config.get("regions"):
            self.set_regions(config["regions"])

    def detection_sign(self) -> int:
        if "sign" not in self.processor_form.field_names:
            return 1
        return int(self.processor_form.values().get("sign", 1))

    def set_theme(self, theme: str) -> None:
        self._theme = Theme_Normalize(theme)
        self.analysis_plot.apply_theme(self._theme)

    def set_display_preferences(self, preferences: Mapping[str, str]) -> None:
        self._display_preferences = dict(preferences)
        self._plot_refresh()

    def _plot_refresh(self) -> None:
        self.analysis_plot.clear_series()
        self._curve_items.clear()
        uncorrected_dataset = self._calibrated_dataset or self._raw_dataset
        uncorrected_channel = self._input_channel_id or ""
        corrected_channel = (
            "thrust_processed"
            if self._processed_dataset is not None
            and "thrust_processed" in self._processed_dataset.channels
            else "thrust_corrected"
        )
        curves: list[tuple[str, Dataset | None, str, int]] = [
            ("uncorrected", uncorrected_dataset, uncorrected_channel, 0),
            ("corrected", self._processed_dataset, corrected_channel, 1),
        ]
        for key, dataset, channel_id, style_index in curves:
            if (
                not self.curve_checks[key].isChecked()
                or dataset is None
                or channel_id not in dataset.channels
            ):
                continue
            item = self.analysis_plot.add_series(
                dataset.project_time,
                dataset.channel(channel_id).display_values(
                    preferences=self._display_preferences
                ),
                name=self._translations.translate(f"process.{key}"),
                style_index=style_index,
            )
            self._curve_items.append(item)
            display_unit = dataset.channel(channel_id).effective_display_unit(
                self._display_preferences
            )
            self.analysis_plot.set_axis(
                x_label=self._translations.translate("common.time"),
                y_label=self._translations.translate("common.value"),
                y_unit=display_unit,
            )
        missing_input = self._input_channel_id is None or uncorrected_dataset is None
        self.analysis_plot.set_empty_state(
            (
                self._translations.translate("workspace.no_primary_thrust")
                if missing_input
                else None
            ),
            button_text=self._translations.translate("workspace.select_thrust"),
            button_visible=True,
        )

    def _regions_view_fit(self) -> None:
        if not self.burn_region.isVisible():
            return
        regions = self.regions()
        pre = regions["pre"]
        burn = regions["burn"]
        post = regions["post"]
        assert burn is not None
        view_start = float(pre[0] if pre is not None else burn[0])
        view_end = float(post[1] if post is not None else burn[1])
        if view_start >= view_end:
            return
        values: list[np.ndarray] = []
        uncorrected_dataset = self._calibrated_dataset or self._raw_dataset
        if self.curve_checks["uncorrected"].isChecked() and uncorrected_dataset is not None:
            channel_id = self._input_channel_id or ""
            if channel_id not in uncorrected_dataset.channels:
                channel_id = ""
            if not channel_id:
                return
            project_time = uncorrected_dataset.project_time
            mask = (project_time >= view_start) & (
                project_time <= view_end
            )
            values.append(
                uncorrected_dataset.channel(channel_id).display_values(
                    preferences=self._display_preferences
                )[mask]
            )
        if self.curve_checks["corrected"].isChecked() and self._processed_dataset is not None:
            channel_id = (
                "thrust_processed"
                if "thrust_processed" in self._processed_dataset.channels
                else "thrust_corrected"
            )
            if channel_id in self._processed_dataset.channels:
                project_time = self._processed_dataset.project_time
                mask = (project_time >= view_start) & (
                    project_time <= view_end
                )
                values.append(
                    self._processed_dataset.channel(channel_id).display_values(
                        preferences=self._display_preferences
                    )[mask]
                )
        self.analysis_plot.fit_view(
            values=tuple(values),
            regions=regions,
        )

    def set_processing_metadata(self, metadata: Mapping[str, Any] | None) -> None:
        values = dict(metadata or {})
        for name in ("pre", "post"):
            baseline = values.get("baseline_start" if name == "pre" else "baseline_end")
            source = values.get(f"baseline_{name}_source")
            if baseline is None:
                text = "—"
            elif source == "assumed_zero":
                text = self._translations.translate(
                    "process.baseline_assumed", value=f"{float(baseline):.8g}"
                )
            else:
                text = self._translations.translate(
                    "process.baseline_measured", value=f"{float(baseline):.8g}"
                )
            self.baseline_status_values[name].setText(text)

    def clear_state(self) -> None:
        self._raw_dataset = None
        self._calibrated_dataset = None
        self._processed_dataset = None
        self._input_channel_id = None
        self._candidates.clear()
        for region in (self.pre_region, self.burn_region, self.post_region):
            region.setVisible(False)
        self._candidate_labels_update()
        self.set_processing_metadata(None)
        self._plot_refresh()
