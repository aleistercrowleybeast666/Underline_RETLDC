"""Application bootstrap and settings."""

